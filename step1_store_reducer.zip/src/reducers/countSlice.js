import {createSlice} from "@reduxjs/toolkit";


const countSlice = createSlice({
    name: "countSlice",
    initialState: {count: 0},
    reducers: {
        inc: state => {
            console.log("inc..........")
        },
        dec: state => {
            console.log("dec..........")
        }
    }
})


export default countSlice.reducer