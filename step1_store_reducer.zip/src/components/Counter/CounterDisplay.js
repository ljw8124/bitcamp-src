import React from 'react';
import {useSelector} from "react-redux";

const CounterDisplay = () => {

    //const {count} = useSelector(state => state)

    // console.log(count) //전역상태로 받음

    return (
        <div>
            <h1>Count :</h1>
        </div>
    );
};

export default CounterDisplay;