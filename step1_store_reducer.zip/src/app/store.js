import {createStore} from "redux";
import countReducer from "../reducers/countReducer";
import {configureStore} from "@reduxjs/toolkit";
import countSlice from "../reducers/countSlice";


export default configureStore({
    reducer: {
        count: countSlice()
    }
})