import Counter from "./components/Counter"

function App() {
  return (
    <div className="App">
      <Counter></Counter>
    </div>
  );
}

export default App;
